<?php

error_reporting(E_ALL);
require_once '../src/includes_all.php';
error_reporting(E_ALL);
include '../../evolya.workgroop/src/wg/starter.php';

// On indique que cette page peut faire l'authentification et le logout
define('SOHO__IS_A_LOGIN_PAGE', true);
define('SOHO__IS_A_LOGOUT_PAGE', true);

// Création d'un configurateur XML
$launcher = new Corp_XmlConfig();

// On passe les models de WG à corp
$launcher->setBean('model.session', ModelManager::get('UserSession'));
$launcher->setBean('model.user', ModelManager::get('TeamMember'));

// Chargement du fichier de config
$launcher->loadFile(dirname(__FILE__) . '/../src/corp2soho/config.xml');

// Récupération du service
$service = $launcher->getBeanByName('service');

// On lance le service
$service->execute();

// On recupère le plugin Soho
$corp2soho = $service->getPlugin('corp2soho');

// Current user
$user = $corp2soho->getCurrentUser();

// On affiche le formulaire d'authentification
if (!$user) {
	
	/*echo '<link rel="stylesheet" type="text/css" href="http://localhost/evolya.workgroop/src/public/core.css"></link>';
	echo '<script src="http://localhost/evolya.workgroop/src/public/jquery-1.7.2.min.js"></script>';
	echo '<script src="http://localhost/evolya.workgroop/src/public/soho.js" charset="UTF-8"></script>';*/
	
	?>
	<body id="wg"><div id="container"><div id="main"><div id="view-login" class="view">
	<?php
	
	$req = $service->getCurrentContext()->getRequest();
	
	$form = $corp2soho->getLoginForm();
	
	echo $form->render($service->getCurrentContext());
	
	echo '</div></div></div></body>';
	
}

else {
	
	$identity = $service->getCurrentContext()->getSession()->getIdentity();
	
	echo '<p>You are <b>' . $identity->getIdentityName() . '</b></p>';
	
	echo '<p>User profile is: <em>' . $identity->getUserModel() . '</em></p>'; 
	
	echo '<p><a href="?logout=1&ts='.time().'">Logout</a></p>';
	
}

// 
$agent = $service->getCurrentContext()->getAgent();
//echo '<hr /><p>You are connected from: ' . $agent;

?>