<?php

class Corp_Test_Request extends UnitTestCase {
	
	/**
	 @var Corp_XmlConfig
	 */
	protected $xmlconfig;
	
	function __construct() {
		parent::__construct('Corp - Request');
		$this->setup();
	}
	
	function setup() {
		
	}

	
}

?>