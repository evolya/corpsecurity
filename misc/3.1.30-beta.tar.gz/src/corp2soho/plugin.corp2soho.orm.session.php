<?php

class Soho_SessionORM implements Corp_Persistence_SessionORM {

	/**
	 * @var MoodelStruct<CorpSession> $model
	 */
	protected $model;
	
	/**
	 * @param Corp_Persistence_Manager $manager
	 */
	protected $manager;
	
	/**
	 * @param MoodelStruct<CorpSession> $model
	 */
	public function __construct(MoodelStruct $model) {
		$this->model = $model;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::getSessions()
	 */
	public function getSessions() {
		$r = array();
		foreach ($this->model->all() as $model) {
			$r[] = $this->model->createSession($model);
		}
		return $r;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::getSession()
	 */
	public function getSession($sid) {
		$model = $this->model->getByID($sid, 1);
		return $model != null ? $this->createSession($model) : null;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::isSessionExists()
	 */
	public function isSessionExists(Corp_Persistence_Session $session) {
		// TODO
		return false;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::insertSession()
	 */
	public function insertSession(Corp_Persistence_Session $session) {
		// TODO
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::updateSession()
	 */
	public function updateSession(Corp_Persistence_Session $session) {
		// TODO
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::deleteSession()
	 */
	public function deleteSession(Corp_Persistence_Session $session) {
		// TODO
		return false;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_SessionORM::getExpiredSessions()
	 */
	public function getExpiredSessions($referenceTime) {
		// TODO
		return array();
	}
	
	/**
	 * @return void
	 */
	public function initialize(Corp_Persistence_Manager $manager) {
		$this->manager = $manager;
	}
	
	/**
	 * @param string $uid
	 * @return boolean
	 */
	public function isEntryExists($uid) {
		// TODO
		return false;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::insertEntry()
	 */
	public function insertEntry(array $data) {
		// TODO
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::updateEntry()
	 */
	public function updateEntry($uid, array $data) {
		// TODO
		$model = $this->model->new;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::getEntry()
	 */
	public function getEntry($uid) {
		return array();
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::deleteEntry()
	 */
	public function deleteEntry($uid) {
		return false;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::deleteEntries()
	 */
	public function deleteEntries($where = array(), $limit = 0) {
		return 0;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::getEntriesIDs()
	 */
	public function getEntriesIDs() {
		return array();
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::getEntries()
	 */
	public function getEntries($where = array(), $limit = 0) {
		return array();
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::supportSQL()
	 */
	public function supportSQL() {
		return true;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see Corp_Persistence_ORM::executeSQL()
	 */
	public function executeSQL($sql) {
		// TODO Rendre le type de retour compatible
		return $this->model->query($sql);
	}
	
}

?>