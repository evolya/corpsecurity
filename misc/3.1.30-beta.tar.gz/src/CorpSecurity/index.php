<?php

// Misc
include 'phar://corpsecurity.phar/corp.serializable.php';

// Exceptions
include 'phar://corpsecurity.phar/corp.exceptions.php';

// XML Config (IOC)
include 'phar://corpsecurity.phar/corp.xmlconfig.php';

// Execution context
include 'phar://corpsecurity.phar/Core/corp.context.php';

// Data persistence
include 'phar://corpsecurity.phar/Persistence/corp.persistence.session.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.session.basic.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.manager.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.manager.abstract.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.manager.stateless.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.manager.phpsession.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.manager.database.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.orm.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.orm.session.php';
include 'phar://corpsecurity.phar/Persistence/corp.persistence.orm.session.defaultmysql.php';

// Service & plugins
include 'phar://corpsecurity.phar/Core/corp.abstractservice.php';
include 'phar://corpsecurity.phar/Core/corp.service.php';
include 'phar://corpsecurity.phar/Core/corp.plugin.php';

// Requests
include 'phar://corpsecurity.phar/Core/corp.request.php';
include 'phar://corpsecurity.phar/Core/corp.request.qop.php';
include 'phar://corpsecurity.phar/Core/corp.request.cli.php';
include 'phar://corpsecurity.phar/Core/corp.request.http.php';

// Agent (ex Places)
include 'phar://corpsecurity.phar/Core/corp.agent.php';

// Identity
include 'phar://corpsecurity.phar/Auth/corp.auth.identity.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.identity.manager.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.identity.manager.htdigest.php';

// Authentication processes
include 'phar://corpsecurity.phar/Auth/corp.auth.process.htbasic.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.process.htdigest.php';

// Permissions managers
include 'phar://corpsecurity.phar/Auth/corp.auth.permissions.manager.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.permissions.acl.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.permissions.flags.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.permissions.unix.php';

// Forms
include 'phar://corpsecurity.phar/Auth/corp.auth.form.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.form.abstract.php';
include 'phar://corpsecurity.phar/Auth/corp.auth.form.basic.php';

// Debuggers
include 'phar://corpsecurity.phar/corp.debugger.php';

?>