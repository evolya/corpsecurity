<?php

class Corp_Exception extends Exception {
	public function __construct(Corp_ExecutionContext $context = null, $message = null, $code = 0, Exception $previous = null) {
		// Si le context est null, c'est une erreur interne, sinon une erreur pendant le traitement de la requete
		parent::__construct($message, $code, $previous);
	}
}

// Classe des exceptions I/O
class Corp_IOException extends Corp_Exception { }

// Erreur interne, potentionnellement suspecte...
class Corp_InternalException extends Corp_Exception { }

// Classe exceptions de sécurité
class Corp_SecurityException extends Corp_Exception { }

/* Security */

class Corp_Exception_Unauthorized extends Corp_SecurityException {
	public function __construct(Corp_ExecutionContext $context = null, $message = 'Unauthorized', Exception $previous = null) {
		parent::__construct($context, $message, 401, $previous);
	}
}

class Corp_Exception_Forbidden extends Corp_SecurityException {
	public function __construct(Corp_ExecutionContext $context = null, $message = 'Forbidden', Exception $previous = null) {
		parent::__construct($context, $message, 403, $previous);
	}
}

class Corp_Exception_UnsupportedOperation extends Corp_SecurityException {
	public function __construct(Corp_ExecutionContext $context = null, $message = 'Unsupported Operation', Exception $previous = null) {
		parent::__construct($context, $message, 501, $previous);
	}
}

class Corp_Exception_NeedPrivileges extends Corp_SecurityException {
	public function __construct($uri, Corp_Auth_Identity $identity, array $failed, Corp_ExecutionContext $context = null, Exception $previous = null) {
		parent::__construct($context, 'Required privileges: ' . implode(', ', $failed), 501, $previous);
	}
}

/* Nodes */

class Corp_Exception_NotFound extends Corp_Exception {
	public function __construct(Corp_ExecutionContext $context = null, $message = 'Not Found', Exception $previous = null) {
		parent::__construct($context, $message, 404, $previous);
	}
}

class Corp_Exception_FileNotFound extends Corp_Exception_NotFound {
	public function __construct(Corp_ExecutionContext $context = null, $file, Exception $previous = null) {
		parent::__construct($context, "File: $file", $previous);
	}
}

class Corp_Exception_NotReadable extends Corp_IOException {
	public function __construct(Corp_ExecutionContext $context = null, $message = 'Not Readable', Exception $previous = null) {
		parent::__construct($context, $message, 500, $previous);
	}
}

class Corp_Exception_FileNotReadable extends Corp_Exception_NotReadable {
	public function __construct(Corp_ExecutionContext $context = null, $file, Exception $previous = null) {
		parent::__construct($context, "File $file not readable", $previous);
	}
}

class Corp_Exception_FileNotWritable extends Corp_Exception_NotReadable {
	public function __construct(Corp_ExecutionContext $context = null, $file, $reason = '', Exception $previous = null) {
		parent::__construct($context, "File '$file' not writable: $reason", $previous);
	}
}

/* Persistence */

class Corp_Persistence_Exception extends Corp_Exception {
	public function __construct(Corp_ExecutionContext $context = null, Corp_Persistence_Manager $manager = null, $message = null, Exception $previous = null) {
		parent::__construct($context, $message, 500, $previous);
	}
}

class Corp_Exception_Database extends Corp_Persistence_Exception {
	public function __construct(Corp_ExecutionContext $context = null, Corp_Persistence_ORM $orm = null, $errmsg = null, $errcode = 0, $sqlQuery = '', Exception $previous = null) {
		parent::__construct($context, null, "$errmsg ($errcode) in request '".addslashes($sqlQuery)."'", $previous);
	}
}

/* XmlConfig */

class Corp_Exception_XmlConfig extends Corp_Exception {
	public function __construct(SimpleXMLElement $rootNode, $message = 'Forbidden', $filename = null, SimpleXMLElement $targetNode = null, Exception $previous = null) {
		parent::__construct(null, $message . ($filename != null ? ', in ' . $filename : ''), 500, $previous);
	}
}

/* Misc */

class Corp_ExceptionInvalidArgument extends Corp_Exception {
	public function __construct($name, $value, $expected, Exception $previous = null) {
		parent::__construct(null, "Invalid argument '$name' with type ".gettype($value).", $expected expected", 500, $previous);
	}
}

?>