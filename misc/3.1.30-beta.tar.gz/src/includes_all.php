<?php

// Misc
require_once 'CorpSecurity/corp.serializable.php';

// Exceptions
require_once 'CorpSecurity/corp.exceptions.php';

// XML Config (IOC)
require_once 'CorpSecurity/corp.xmlconfig.php';

// Execution context
require_once 'CorpSecurity/Core/corp.context.php';

// Data persistence
require_once 'CorpSecurity/Persistence/corp.persistence.session.php';
require_once 'CorpSecurity/Persistence/corp.persistence.session.basic.php';
require_once 'CorpSecurity/Persistence/corp.persistence.manager.php';
require_once 'CorpSecurity/Persistence/corp.persistence.manager.abstract.php';
require_once 'CorpSecurity/Persistence/corp.persistence.manager.stateless.php';
require_once 'CorpSecurity/Persistence/corp.persistence.manager.phpsession.php';
require_once 'CorpSecurity/Persistence/corp.persistence.manager.database.php';
require_once 'CorpSecurity/Persistence/corp.persistence.orm.php';
require_once 'CorpSecurity/Persistence/corp.persistence.orm.session.php';
require_once 'CorpSecurity/Persistence/corp.persistence.orm.session.defaultmysql.php';

// Service & plugins
require_once 'CorpSecurity/Core/corp.abstractservice.php';
require_once 'CorpSecurity/Core/corp.service.php';
require_once 'CorpSecurity/Core/corp.plugin.php';

// Requests
require_once 'CorpSecurity/Core/corp.request.php';
require_once 'CorpSecurity/Core/corp.request.qop.php';
require_once 'CorpSecurity/Core/corp.request.cli.php';
require_once 'CorpSecurity/Core/corp.request.http.php';

// Agent (ex Places)
require_once 'CorpSecurity/Core/corp.agent.php';

// Identity
require_once 'CorpSecurity/Auth/corp.auth.identity.php';
require_once 'CorpSecurity/Auth/corp.auth.identity.manager.php';
require_once 'CorpSecurity/Auth/corp.auth.identity.manager.htdigest.php';

// Authentication processes
require_once 'CorpSecurity/Auth/corp.auth.process.htbasic.php';
require_once 'CorpSecurity/Auth/corp.auth.process.htdigest.php';

// Permissions managers
require_once 'CorpSecurity/Auth/corp.auth.permissions.manager.php';
require_once 'CorpSecurity/Auth/corp.auth.permissions.acl.php';
require_once 'CorpSecurity/Auth/corp.auth.permissions.flags.php';
require_once 'CorpSecurity/Auth/corp.auth.permissions.unix.php';

// Forms
require_once 'CorpSecurity/Auth/corp.auth.form.php';
require_once 'CorpSecurity/Auth/corp.auth.form.abstract.php';
require_once 'CorpSecurity/Auth/corp.auth.form.basic.php';

// Debuggers
require_once 'CorpSecurity/corp.debugger.php';

?>